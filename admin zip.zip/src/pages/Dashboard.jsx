import { useCallback, useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabase'

const money = n => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(n || 0))
const goodPayment = s => ['succeeded','paid','completed','success'].includes(String(s || '').toLowerCase())
const dateLabel = d => d ? new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric'}).format(new Date(`${d}T12:00:00`)) : '—'

export default function Dashboard({ session }) {
  const [bookings,setBookings]=useState([])
  const [payments,setPayments]=useState([])
  const [loading,setLoading]=useState(true)
  const [error,setError]=useState('')

  const load = useCallback(async () => {
    setLoading(true); setError('')
    const [b,p] = await Promise.all([
      supabase.from('bookings').select('*').order('appointment_date',{ascending:true}).order('appointment_time',{ascending:true}),
      supabase.from('payments').select('*').order('created_at',{ascending:false})
    ])
    if (b.error || p.error) setError(b.error?.message || p.error?.message || 'Could not load dashboard data.')
    else { setBookings(b.data || []); setPayments(p.data || []) }
    setLoading(false)
  },[])

  useEffect(() => {
    load()
    const channel = supabase.channel('admin-dashboard')
      .on('postgres_changes',{event:'*',schema:'public',table:'bookings'},load)
      .on('postgres_changes',{event:'*',schema:'public',table:'payments'},load)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  },[load])

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0,10)
    const revenue = payments.filter(p=>goodPayment(p.status)).reduce((s,p)=>s+Number(p.amount||0),0)
    return {
      revenue,
      today: bookings.filter(b=>b.appointment_date===today).length,
      upcoming: bookings.filter(b=>b.appointment_date>=today && !['cancelled','completed'].includes(String(b.status).toLowerCase())).length,
      pending: bookings.filter(b=>['pending','confirmed','scheduled'].includes(String(b.status).toLowerCase())).length,
      completed: bookings.filter(b=>String(b.status).toLowerCase()==='completed').length
    }
  },[bookings,payments])

  async function signOut(){ await supabase.auth.signOut() }

  return (
    <main>
      <header className="topbar">
        <div><div className="brand small">VISO</div><span>Mobile Autocare · Admin</span></div>
        <div className="top-actions"><span>{session.user.email}</span><button className="ghost" onClick={signOut}>Sign out</button></div>
      </header>

      <div className="wrap">
        <section className="heading">
          <div><p className="eyebrow">Operations</p><h1>Good to see you.</h1><p className="muted">Here's what's happening across Viso Mobile Autocare.</p></div>
          <button className="ghost" onClick={load}>{loading ? 'Refreshing…' : 'Refresh'}</button>
        </section>

        {error && <div className="error">{error}</div>}

        <section className="stats">
          <Stat label="Revenue" value={money(stats.revenue)} note="Successful payments" />
          <Stat label="Today's bookings" value={stats.today} note="Scheduled today" />
          <Stat label="Upcoming" value={stats.upcoming} note="Future appointments" />
          <Stat label="Pending" value={stats.pending} note="Awaiting completion" />
        </section>

        <section className="panel">
          <div className="panel-head"><div><p className="eyebrow">Bookings</p><h2>Recent activity</h2></div></div>
          {loading ? <div className="empty">Loading bookings…</div> : !bookings.length ? <div className="empty"><strong>No bookings yet.</strong><span>New customer bookings will appear here.</span></div> :
          <div className="scroll"><table><thead><tr><th>Customer</th><th>Service</th><th>When</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead>
          <tbody>{bookings.slice(-15).reverse().map(b=>{
            const p=payments.find(x=>x.booking_id===b.id)
            return <tr key={b.id}>
              <td><strong>{b.customer_name||'Unknown'}</strong><span>{b.customer_email||'—'}</span></td>
              <td>{b.service_name||'Service'}</td>
              <td><strong>{dateLabel(b.appointment_date)}</strong><span>{String(b.appointment_time||'').slice(0,5)||'—'}</span></td>
              <td>{money(b.total)}</td><td><Badge value={b.status}/></td><td><Badge value={p?.status||b.payment_status} /></td>
            </tr>
          })}</tbody></table></div>}
        </section>

        <section className="side">
          <div><p className="eyebrow">This month</p><h2>{stats.completed}</h2><p className="muted">completed bookings</p></div>
          <div className="coming"><span>NEXT</span><strong>Admin availability & live location</strong><p>Your admin account will become the first Viso technician, with working hours and live location controls.</p></div>
        </section>
      </div>
    </main>
  )
}

function Stat({label,value,note}){return <article className="stat"><p>{label}</p><strong>{value}</strong><span>{note}</span></article>}
function Badge({value}){const v=String(value||'pending').toLowerCase(); const good=goodPayment(v)||['confirmed','scheduled'].includes(v); return <span className={`badge ${good?'good':''}`}>{value||'pending'}</span>}
